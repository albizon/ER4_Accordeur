/*
 * TP_info2.c
 * TP5
 * IUT de Nantes
 * Created by : Mr. M�tayer Simon & Mr. Bizon Alexis
 * Date : 29/04/2016
 */ 

#include "fonc.h"
#include "sam.h"
#include "stdio.h"
	
int main(void)
{
	setup();//Fonction d'initialisation 
	while(1)
	{
		uint32_t tab[3] = {0,SAMD21_ADC_MUX_AIN2,SAMD21_ADC_MUX_AIN3};
		int16_t val = read_adc(tab);
		OLEDSetLine(0);
		printf("%d       \n", val);
	}
	return 0;
}

