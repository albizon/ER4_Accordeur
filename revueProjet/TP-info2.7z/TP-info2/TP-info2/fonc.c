#include "fonc.h"//
#include "genericSystem.h"

extern int FREQUENCE;

extern void init_ES(void)//Initialisation des entr�es et sorties du micro-controlleur en fonction des besoins du TP
{
	pinMode(PORTB,10,OUTPUT); // Configuration de PB10 en sortie
	pinMode(PORTB,11,INPUT); // Configuration de PA20 en sortie
	PORT->Group[1].DIRSET.reg = 0xFF; //Configuration de PB0 � PB7 en sortie
	EICInitClock(F32KHZ); //Initialisation de l�horloge pour la d�tection de fronts
	//pinMux(PORTB,11,CONFIG_A); // Configuration de la broche 11 du port B sur son p�riph�rique A qui est l�EIC
	pinMux(PORTB,8,CONFIG_B);
	pinMux(PORTB,9,CONFIG_B);
	EICConfig(11,1,BOTH); //Configuration de l�EIC 11 en d�tection de fronts descendants avec filtre
	NVIC_EnableIRQ(EIC_IRQn); // Validation NVIC pour les interruptions EIC
	NVIC_SetPriority(EIC_IRQn,1); // Priorit� de 2 pour les interruptions EIC
}

void init_adc(
				uint32_t *args)
								/*
								args[0] = clock source
								args[1] = ref
								args[2] = diviseur de fr�quence							
								*/
{
	static uint8_t firstInit=TRUE;
	if(firstInit){
		//Power Management.
		PM->APBCMASK.reg |= 1 << 16; //ADC
		
		//horloge: generateur 3 (8MHz)
		GCLK->CLKCTRL.reg = 1 <<14 | //enable
							args[0] << 8 | //generator
							0x1E;	 //ADC
		//calibration d'usine:
		ADC->CALIB.reg =
			ADC_CALIB_BIAS_CAL(
				(*(uint32_t *)ADC_FUSES_BIASCAL_ADDR >> ADC_FUSES_BIASCAL_Pos)
			) |
			ADC_CALIB_LINEARITY_CAL(
				(*(uint64_t *)ADC_FUSES_LINEARITY_0_ADDR >> ADC_FUSES_LINEARITY_0_Pos)
		);
		
		//config ADC
		ADC->REFCTRL.reg |= args[1];		//r�f�rence de tension
		ADC->CTRLB.reg = 	args[2] << 8 |  //diviseur de fr�quence
							0x1 << 0;		//mode diff�rentiel
		ADC->CTRLA.reg |= 1<<1; //enable
		firstInit=FALSE;
	}
	
}

int16_t read_adc(
					uint32_t *args)
									/*
									args[0] = gain
									args[1] = ref negative
									args[2] = ref positive	
									*/
{
	int16_t result=0;
	//choix du canal de conversion.
	ADC->INPUTCTRL.reg = 0x0 | 
						args[0] << 24 | //gain
						args[1] << 8 | //ref negative
						args[2] << 0;  //ref positive
						
	//RAZ flag de fin de conversion (avec un 1!)
	ADC->INTFLAG.reg = 0x1; //RAZ RESRDY
	//demande de conversion
	ADC->SWTRIG.reg = 1 << 1; //start.
	while(!(ADC->INTFLAG.bit.RESRDY)); //attente fin de conversion.
	int16_t sign = ((ADC->RESULT.reg & 0x8000) );
	uint16_t val = ((ADC->RESULT.reg & 0x07FF));
	//result = ((ADC->RESULT.reg & 0x0800) <<4)| ((ADC->RESULT.reg & 0x07FF));
	//result = ((ADC->RESULT.reg & 0x0800))| ((ADC->RESULT.reg & 0x07FF)>>4);
	//result = ADC->RESULT.reg; //resultat sur 12 bits.
	
	return sign;
}

void timer_init() // Initialisation des timer(s) n�c�ssaires
{
	// TIMER TC3
	//TCinitClock(F1MHZ,3); // Initialisation de l'horloge � 1MHz pour le timer TC3
	TC3->COUNT16.CTRLA.reg= (0x1<<8); // intialisation d'un prescaler de '001' (2)
	TC3->COUNT16.CTRLBSET.reg=0x1; // Initialisation du timer en incr�mentation
	TC3->COUNT16.COUNT.reg=50000; // Chargement du compteur
	TC3->COUNT16.INTFLAG.reg=0x1; // Validation de l'overflow
	TC3->COUNT16.CTRLA.reg |=2; // D�marrage du timer
	TC3->COUNT16.INTENSET.reg=1; // Validation locale des interruptions provoqu�e par TC3
	NVIC_EnableIRQ(TC3_IRQn); // Validation NVIC du timer TC3 pour les interruptions
	NVIC_SetPriority(TC3_IRQn,2); // Priorit� de 1 pour les interruptions du timer TC3
	
	// TIMER TC6
	//TCinitClock(F1MHZ,6); // Initialisation de l'horloge � 8MHz pour le timer TC6
	TC6->COUNT16.CTRLA.reg= (0x0<<8); // intialisation d'un prescaler de '011' (8)
	TC6->COUNT16.CTRLBCLR.reg= 0x1; // Initialisation du timer en incr�mentation
	TC6->COUNT16.INTFLAG.reg=0x1; // Validation de l'overflow
	TC6->COUNT16.CTRLA.reg |=2; // D�marrage du timer	
}

void setup(void)//Fonction d'initialisation
{
	init_system(0);
	//SystemInit();//Initialisation des param�tres syst�mes
	redirectPrintf(PRINTF_OLED);//On redirige les instructions de la fonction printf sur l'afficheur OLED
	init_ES();//On initialise les entr�es et sorties du micro-controlleur selon les besoins du TP (pour plus de pr�cisions, voir la fonction init_ES)
	OLEDInit(0);//On initialise notre afficheur OLED avec aucune image
	OLEDClear();//On efface les valeurs qui pourraient �tre affich�es sur l'afficheur OLED
	timer_init(); // Initialisation du/des timer(s) n�c�ssaires
	uint32_t tab[3] ={F8MHZ,0,SAMD21_ADC_VREF_INT1V};
	init_adc(tab);
	
}

void delay_us(int time)//met en pause le programme pendant time ms EX : delay(1000)->mise en pause du programme pendant 1 milliseconde
{
	volatile int i;//d�claration d'un entier de type volatile
	for(i=0; i<2*time; i++)//Boucle de comptage de 0 � 1000*time pour compter pendant time ms
	{
	}
}

void display_Title(void)//Affichage de la cha�ne de caract�re "TP6" sur la premi�re ligne de l'afficheur OLED
{
	OLEDSetLine(0);//On se place sur la premi�re ligne de l'afficheur OLED (r�f�renc�e en 0)
	OLEDPrintString("TP6");//Affichage de la cha�ne de caract�re "TP5" sur la ligne pr�c�demment s�l�ctionn�e de l'afficheur OLED
}
void salve(void)
{
	digitalWrite(PORTB,10,1);//d�but de l'envoi du signal de commande
	delay_us(10);//attente de 10 us
	digitalWrite(PORTB,10,0);//fin de l'envoi du signal de commande
}

void bargraph (int value, int max) // Allumage de leds du bragraph (8leds) proportionnellement � la distance (compris entre 10cm et 1m)
{
	int i,k =0; 
	PORT->Group[1].OUTCLR.reg=0xFF; // ALLUME toute les leds
	if (value < max) // si ma valeur est inf�rieur au max
	{
		for(i=0; i<8; i++) // balayage des leds
		{
			if(value>=(i*max/8) && (value<((i+1)*max/8))) // calcul de proportionnalit�
			{
				for(k=0;k<=i;k++) // balayage des valeurs
				{
				PORT->Group[1].OUTSET.reg=1<<(k-1); // ETEINDRE la led corresponante au balayage
				}
			}
		}
	}
	else PORT->Group[1].OUTSET.reg=0xFF; // sinon on ETEIND toutes les leds (trop loin)
	
}


