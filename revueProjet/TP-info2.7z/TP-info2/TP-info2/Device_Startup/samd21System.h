/*
* Accordeur de Guitare
* Authors : METAYER Simon & BIZON Alexis
* Created Date : 03/02/17
* Version : 2.0
*/

#ifndef __SAMD21SYSTEM_H__
#define __SAMD21SYSTEM_H__

#include "sam.h"


#endif