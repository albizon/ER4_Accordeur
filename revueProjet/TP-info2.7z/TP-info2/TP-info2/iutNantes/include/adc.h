#ifndef __ADC_H__
#define __ADC_H__

int ADCInit();

//renvoie la lecture ADC sur 12 bits.
int ADCRead(int canal);

#endif
