#ifndef __CLOCK_H__
#define __CLOCK_H__

//ne pas modifier les valeurs:
//directement les valeurs des generateurs (clk generator)
#define F48MHZ 0
#define F8MHZ  3
#define F1MHZ  4
#define F32KHZ 1

#endif
