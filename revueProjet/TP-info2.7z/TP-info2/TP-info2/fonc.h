#ifndef __FONC_H__
#define __FONC_H__

#include "define.h"
#include "sam.h" //definition des registres
#include "oled.h"
#include "pinAccess.h"
#include "eic.h"
#include "pinMux.h"
#include "redirectPrintf.h"
#include "dac.h"
#include "adc.h"

#define TRUE 1
#define FALSE 0

#define SAMD21_ADC_VREF_INT1V 0x0
#define SAMD21_ADC_VREF_INTVCC0 0x1
#define SAMD21_ADC_VREF_INTVCC1 0x2
#define SAMD21_ADC_VREF_VREFA 0x3
#define SAMD21_ADC_VREF_VREFB 0x4

#define SAMD21_ADC_MUX_AIN0 0x00
#define SAMD21_ADC_MUX_AIN1 0x01
#define SAMD21_ADC_MUX_AIN2 0x02
#define SAMD21_ADC_MUX_AIN3 0x03
#define SAMD21_ADC_MUX_AIN4 0x04
#define SAMD21_ADC_MUX_AIN5 0x05
#define SAMD21_ADC_MUX_AIN6 0x06
#define SAMD21_ADC_MUX_AIN7 0x07
#define SAMD21_ADC_MUX_AIN8 0x08
#define SAMD21_ADC_MUX_AIN9 0x09
#define SAMD21_ADC_MUX_AIN10 0x0A
#define SAMD21_ADC_MUX_AIN11 0x0B
#define SAMD21_ADC_MUX_AIN12 0x0C
#define SAMD21_ADC_MUX_AIN13 0x0D
#define SAMD21_ADC_MUX_AIN14 0x0E
#define SAMD21_ADC_MUX_AIN15 0x0F
#define SAMD21_ADC_MUX_AIN16 0x10
#define SAMD21_ADC_MUX_AIN17 0x11
#define SAMD21_ADC_MUX_AIN18 0x12
#define SAMD21_ADC_MUX_AIN19 0x13

#define SAMD21_ADC_MUX_GND 0x18
#define SAMD21_ADC_MUX_IOGND 0x19

#define SAMD21_ADC_MUX_TEMP 0x18
#define SAMD21_ADC_MUX_BANDGAP 0x19
#define SAMD21_ADC_MUX_SCALEDCOREVCC 0x1A
#define SAMD21_ADC_MUX_SCALEDIOVCC 0x1B
#define SAMD21_ADC_MUX_DAC 0x1C


extern void init_ES(void);//Initialisation des entr�es et sorties du micro-controlleur en fonction des besoins du TP
void timer_init(void); // Initialisation du/des timer(s) n�c�ssaires
void setup(void);//Fonction d'initialisation
void delay_us(int time);//met en pause le programme pendant time us. EX : delay(1000)->mise en pause du programme pendant 1 milli-seconde
void display_Title(void);//Affichage de la cha�ne de caract�re "TP6" sur la premi�re ligne de l'afficheur OLED
void salve(void);//met le port b 10 au niveau haut pendant 10 us
void bargraph (int value, int max); // Allumage de leds du bragraph (8leds) proportionnellement � la distance (compris entre 10cm et 1m)

void init_adc(uint32_t *args);
int16_t read_adc(uint32_t *args);

#endif