#ifndef __DEFINE_H__
#define __DEFINE_H__
	#define MAX_MESURE 1000
#endif
